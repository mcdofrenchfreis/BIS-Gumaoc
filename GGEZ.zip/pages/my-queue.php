<?php
<?php
session_start();
$base_path = '../';
$page_title = 'My Queue Tickets - Barangay Gumaoc East';
$header_title = 'My Queue Tickets';// filepath: c:\xampp\htdocs\GUMAOC\pages\my-queue.php
<?php
session_start();
$base_path = '../';
$page_title =